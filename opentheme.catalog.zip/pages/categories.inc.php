<div id="content">
  <?php include vmod::check(FS_DIR_APP . 'includes/boxes/box_categories.inc.php'); ?>
</div>